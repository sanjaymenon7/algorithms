package ShivBellFord;

public class Edge {

		public int src;
		public int dest;
		public int cost;
		public Edge(int s,int d,int c)
		{
			src=s;
			dest=d;
			cost=c;
		}
}
